package com.quirko.logic.events;

public enum EventSource {
    USER, THREAD
}
