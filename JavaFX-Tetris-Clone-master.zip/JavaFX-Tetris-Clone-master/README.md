JavaFX Tetris Clone Game
=============

JavaFX Tetris Clone Game

## Screenshots
<p align="center">
  <img src="https://github.com/javafx-dev/javafx-dev.github.io/blob/master/img/tetris-screen1.jpg?raw=true" alt="TetrisJFX Screen Shoot"/>
  <img src="https://github.com/javafx-dev/javafx-dev.github.io/blob/master/img/tetris-screen2.jpg?raw=true" alt="TetrisJFX Screen Shoot 1"/>
</p>

## Gameplay
See Youtube: <a href="https://www.youtube.com/watch?v=uzyOOlCvQN0">https://www.youtube.com/watch?v=uzyOOlCvQN0</a>
